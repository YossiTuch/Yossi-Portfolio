import { registerForm, loginForm, drawTableRows } from './domService.js';
import { User } from './User.js';

drawTableRows(User.usersList);
